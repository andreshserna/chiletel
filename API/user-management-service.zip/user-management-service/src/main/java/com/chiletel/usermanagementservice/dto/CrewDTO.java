package com.chiletel.usermanagementservice.dto;

import lombok.Data;

@Data
public class CrewDTO {

    private Long crewId;
    private String name;
    private String zone;
}
