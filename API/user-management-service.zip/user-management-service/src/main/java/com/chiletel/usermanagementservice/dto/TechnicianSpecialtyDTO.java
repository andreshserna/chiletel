package com.chiletel.usermanagementservice.dto;

import lombok.Data;

@Data
public class TechnicianSpecialtyDTO {
    private Long technicianId;
    private Long damageId;
}
