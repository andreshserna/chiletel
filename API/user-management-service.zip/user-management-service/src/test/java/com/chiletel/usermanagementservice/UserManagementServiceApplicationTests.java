package com.chiletel.usermanagementservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
