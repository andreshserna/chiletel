package com.chiletel.damageorderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DamageOrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
