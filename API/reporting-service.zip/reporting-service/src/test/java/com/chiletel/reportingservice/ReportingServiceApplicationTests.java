package com.chiletel.reportingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
