package com.chiletel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedulingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
