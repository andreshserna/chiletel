package com.chiletel.schedulingservice.dto;

import lombok.Data;

@Data
public class TechnicianSpecialtyDTO {
    private Long technicianId;
    private Long damageId;
}
