package com.chiletel.schedulingservice.dto;

import lombok.Data;

@Data
public class CrewDTO {

    private Long crewId;
    private String name;
    private String zone;
}
