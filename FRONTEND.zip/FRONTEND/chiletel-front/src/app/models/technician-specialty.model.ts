export class TechnicianSpecialty {
    technicianId: number;
    damageId: number;
  }