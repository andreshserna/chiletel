export class Technician {
    technicianId: number;
    name: string;
    document: string;
    documentType: string;
    crewId: number;

    
  }