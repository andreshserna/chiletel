export class Damage {
  damageId: number;
  description: string;
  priority: number; // 1 a 5
  estimatedDuration?: string;
}