import { Component } from '@angular/core';

@Component({
  selector: 'app-create-manual-schedule',
  templateUrl: './create-manual-schedule.component.html',
  styleUrls: ['./create-manual-schedule.component.sass']
})
export class CreateManualScheduleComponent {

}
