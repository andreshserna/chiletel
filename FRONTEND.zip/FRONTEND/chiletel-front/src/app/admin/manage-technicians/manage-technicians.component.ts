import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-technicians',
  templateUrl: './manage-technicians.component.html',
  styleUrls: ['./manage-technicians.component.sass']
})
export class ManageTechniciansComponent {

}
