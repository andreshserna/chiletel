import { TechnicianSpecialty } from '../src/app/models/technician-specialty.model';

describe('TechnicianSpecialty', () => {
  it('should create an instance', () => {
    expect(new TechnicianSpecialty()).toBeTruthy();
  });
});
