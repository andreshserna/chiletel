import { Damage } from '../src/app/models/damage.model';

describe('Damage', () => {
  it('should create an instance', () => {
    expect(new Damage()).toBeTruthy();
  });
});
