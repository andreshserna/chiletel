import { Technician } from '../src/app/models/technician.model';

describe('Technician', () => {
  it('should create an instance', () => {
    expect(new Technician()).toBeTruthy();
  });
});
