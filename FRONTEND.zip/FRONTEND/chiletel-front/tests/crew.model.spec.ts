import { Crew } from '../src/app/models/crew.model';

describe('Crew', () => {
  it('should create an instance', () => {
    expect(new Crew()).toBeTruthy();
  });
});
