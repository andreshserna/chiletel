import { AttentionOrder } from '../src/app/models/attention-order.model';

describe('AttentionOrder', () => {
  it('should create an instance', () => {
    expect(new AttentionOrder()).toBeTruthy();
  });
});
